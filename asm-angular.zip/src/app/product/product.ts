export interface ProductType {
    id: number;
    name: string;
    image: string;
    desc: string;
    price: number;
    status: boolean;
} 